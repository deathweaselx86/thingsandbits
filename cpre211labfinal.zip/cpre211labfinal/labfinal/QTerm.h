// QTerm.h : Special files for QTerm display on PowerPC education board
///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2001	Iowa State University 
// All rights reserved.
//
// Department of Electrical & Computer Engineering
// Iowa State University
// Ames, IA 50010
//
// http://www.ee.iastate.edu/
//
///////////////////////////////////////////////////////////////////////////////
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
// 3. All advertising materials mentioning features or use of this software
//    must display the following acknowledgement:
// 		This product includes software developed by the Iowa State 
//      University.
// 4. Neither the name of the University nor of the Research Group may be used
//    to endorse or promote products derived from this software without
//    specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////////

#ifndef __QTERM_H
#define __QTERM_H

///////////////////////////////////////////////////////////////////////////////
// Function Prototypes

void		LCD_Init 	();
void		LCD_Clear 	();
void		LCD_Reset	();

// Cursor movement

void		LCD_MoveCursor		(int nX, int nY);
void		LCD_GotoXY			(int nX, int nY);

void		LCD_GetPos			(int * nX, int * nY);
char		LCD_GetCharAtPos	();

void		LCD_ClearBuffer		();
void		LCD_PutChar			(char);
void		LCD_PutString		(char *);

// Automatic modes

void		Set_LCD_AutoWrap		(char bWrap);
void		Set_LCD_AutoScroll		(char bScroll);
void		Set_LCD_AutoLineFeed	(char bLineFeed);

// Misc. commands

void		Set_LCD_Contrast		(char nLevel);

#define LCD_BACKLIGHT_ON			0
#define LCD_BACKLIGHT_OFF			1
#define LCD_BACKLIGHT_TOGGLE		2

void		Set_LCD_Backlight		(char nLight);

#define LCD_CURSOR_NONE				0
#define LCD_CURSOR_LINE				1
#define LCD_CURSOR_BLOCK			2
#define LCD_CURSOR_FULL				3

void		Set_LCD_CursorType		(char nType);

///////////////////////////////////////////////////////////////////////////////
// Keyboard assignments for QTerm special keys
///////////////////////////////////////////////////////////////////////////////

#define	QTERM_F1_KEY			0x65		// F1 key
#define	QTERM_F2_KEY			0x66		// F2 key
#define	QTERM_F3_KEY			0x67		// F3 key
#define	QTERM_F4_KEY			0x68		// F4 key
#define	QTERM_F5_KEY			0x69		// F5 key
#define QTERM_ESC_KEY			0x1B		// ESC key
#define	QTERM_DEL_KEY			0x7F		// DEL key
#define QTERM_SPACE_KEY			0x20		// SPACE key
#define QTERM_ENTER_KEY			0x0D		// ENTER key
#define QTERM_UP_ARROW_KEY		0x61		// UP arrow key
#define QTERM_DOWN_ARROW_KEY	0x62		// DOWN arrow key
#define QTERM_RIGHT_ARROW_KEY	0x63		// RIGHT arrow key
#define QTERM_LEFT_ARROW_KEY	0x64		// LEFT arrow key

///////////////////////////////////////////////////////////////////////////////
// Single-key commands

#define	QTERM_BSPACE			0x08		// Back up 1 space (no erase)
#define	QTERM_HTAB				0x09
#define	QTERM_LINEFEED			0x0A
#define	QTERM_VTAB				0x0B		// Same function as line feed
#define QTERM_FORMFEED			0x0C		// Same function as line feed
#define QTERM_CR				0x0D		// Carriage return
											//	 If auto-feed is on, will go to next
											//   line and back to left											

#define	QTERM_DELETE			0x7F		// Back up 1 space and delete char


#define QTERM_ESCAPE			0x1B		// Escape key

///////////////////////////////////////////////////////////////////////////////
// All commands beyond those listed above are sent via an escape key +
// one of the following keys


#define QTERM_CURSOR_UP			'A'			// Move up 1 line
#define QTERM_CURSOR_DOWN		'B'			// Move down 1 line
#define QTERM_CURSOR_RIGHT		'C'			// Move right one space
#define QTERM_CURSOR_LEFT		'D'			// Move left one space

#define QTERM_CLEAR_SCREEN		'E'			// Clear screen and return to
											// upper left position
											
#define	QTERM_CURSOR_HOME		'H'			// Return to upper left position

#define	QTERM_SET_POS			'I'			// Set cursor position
											//   Followed by two characters
											// 		Row, Column
											//	 using (@=0,A=1,B=2,...)
											
#define QTERM_ERASE_END_SCREEN	'J'			// Erase to the end of the screen
#define	QTERM_ERASE_END_LINE	'K'			// Erase to the end of the line

#define QTERM_SET_CONTRAST		'L'			// Change contrast
											//  Followed by a key from 0x40 to 0x7F

#define QTERM_RESET				'M'			// Reset to power-up state

#define	QTERM_QUERY_VERSION		'N'			// Query the version #

#define QTERM_AUTO_WRAP			'R'			// Change Auto-Wrap
											//	@ = Off
											//  A = On
											
#define QTERM_AUTO_SCROLL		'S'			// Change Auto-Scroll
											//	@ = Off
											//  A = On

#define QTERM_AUTO_LINEFEED		'T'			// Change Auto-Linefeed
											//	@ = Off
											//  A = On																						

#define QTERM_BACKLIGHT			'V'			// Change Backlight
											//	@ = Off
											//  A = On
											//	B = Toggle		
											
#define QTERM_QUERY_POS			'X'			// Query position of cursor
											//   Returns as @,A,B,C etc.

#define QTERM_QUERY_CHAR		'Y'			// Query char at current pos																																										


#define QTERM_SET_CURSOR_MODE	'a'			// Set cursor mode
											//	@ = None
											//	A = Underline only
											// 	B = Block only
											//	C = Block + Underline
																					

#endif
