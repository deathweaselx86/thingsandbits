// Defines.h : Definition file for PowerPC ops
/////////////////////////////////////////////////////////////////////////

#ifndef __DEFINES_H
#define __DEFINES_H

/////////////////////////////////////////////////////////////////////////
// Overall memory addresses for external I/O board
//	32 bit pointer
//

#define		ADDRESS_START_EXT_RAM		0x20000000
#define		ADDRESS_START_EXT_IO		0x40000000

/////////////////////////////////////////////////////////////////////////
// I/O ports
//
//	All I/O ports are 8 bit ports
//

#define IO_DIGITAL_INPUT_1				0x40000003
#define IO_DIGITAL_INPUT_2				0x40000007
#define IO_DIGITAL_INPUT_DIP_1			0x4000000B
#define IO_DIGITAL_INPUT_DIP_2			0x4000000F
#define IO_DIGITAL_INPUT_KEYPAD			0x40000013
#define IO_DIGITAL_OUTPUT_LED1			0x40000023
#define IO_DIGITAL_OUTPUT_LED2			0x40000027
#define IO_DIGITAL_OUTPUT_1				0x4000002B
#define IO_DIGITAL_OUTPUT_2				0x4000002F
#define IO_DIGITAL_OUTPUT_7SEG			0x40000033

//////////////////////////////////////////////////////////////////////////
// Serial Operations
//
//	Port Selection
//

#define 	SERPORT_PC					0
#define		SERPORT_LCD					1
#define		SERPORT_SCI1				0
#define		SERPORT_SCI2				1

#define	COM1CON0   0x305008   // SCI1 control register 0
#define	COM1CON1   0x30500A   // SCI1 control register 1
#define	COM1STATUS 0x30500C	// SCI1 status register
#define	COM1DATA 0x30500E   // SCI1 data register

#define	COM2CON0   0x305020   // SCI2 control register 0
#define	COM2CON1   0x305022   // SCI2 control register 1
#define	COM2STATUS 0x305024 	// SCI2 status register
#define	COM2DATA   0x305026   // SCI2 data register
#endif

