/* ===========================================================================
	serial.h
	--------
	Header file for serial.c

 (C) Copyright 1999 Axiom Manufacturing.  All rights reserved.
============================================================================*/

#ifndef D_serial
#define D_serial

#include "diab.h"

/*------------
 CONSTANTS
------------*/

#define LF 10			/* line feed */
#define CR 13			/* carriage return */

//#define	INBUFSIZE	255		// size in bytes of the serial input buffer
//#define	INBUFSIZE	32		// size in bytes of the serial input buffer
#define	INBUFSIZE	128		// size in bytes of the serial input buffer

/*------------
I/O Registers
------------*/
#define	Com1Con0   *(unsigned short volatile *)(0x305008)   // SCI1 control register 0
#define	Com1Con1   *(unsigned short volatile *)(0x30500A)   // SCI1 control register 1
#define	Com1Status *(unsigned short volatile *)(0x30500C) 	// SCI1 status register
#define	Com1Data   *(unsigned short volatile *)(0x30500E)   // SCI1 data register

#define	Com2Con0   *(unsigned short volatile *)(0x305020)   // SCI2 control register 0
#define	Com2Con1   *(unsigned short volatile *)(0x305022)   // SCI2 control register 1
#define	Com2Status *(unsigned short volatile *)(0x305024) 	// SCI2 status register
#define	Com2Data   *(unsigned short volatile *)(0x305026)   // SCI2 data register

#define	MPIOSMDR  *(unsigned short volatile *)(0x306100) 	// MPIOSM data register
#define	MPIOSMDDR *(unsigned short volatile *)(0x306102) 	// MPIOSM data direction register - 1 = output

#define	QADC1DR   *(unsigned short volatile *)(0x304806)  	// QADC 1 data register
#define	QADC1DDR  *(unsigned short volatile *)(0x304808) 	// QADC 1 data direction register (port A)
#define	QADC2DR   *(unsigned short volatile *)(0x304C06)  	// QADC 2 data register
#define	QADC2DDR  *(unsigned short volatile *)(0x304C08) 	// QADC 2 data direction register (port A)

#define	PORTQS    *(unsigned short volatile *)(0x305014)  	// QSM data register
#define	PQSPAR    *(unsigned short volatile *)(0x305016)  	// QSM data direction register

#define	WatchDog  *(unsigned short volatile *)(0x2FC00E) 	// SWSR software service register

/*------------
RAM Variables
------------*/
extern UNS8 SByte;	// global byte, contained just received data byte
extern UNS8 inbuf[INBUFSIZE];
extern UNS8 inbyte;
extern UNS16 Rcount, Wcount;
extern UNS32 Addr, StartAddr, EndAddr;
extern UNS16 ioport;	// 0 = use SC0 for standard i/o.  1 = use SC1
extern UNS8 echo;

/*------------
 Functions
------------*/

void init_uarts();
char ReadyToSend(char portnum);
UNS8 putchar(UNS8 sbyte);
void putch(UNS8 ch);
void puts(char *sptr);

UNS8 SerialReady(UNS8 portnum);
char ReadSerialPort(char pnum);
UNS8 GetSByte();
UNS8 GetString();

char hexvalue(char number);
UNS16 strlength(char *sptr);
void reverse(char *rptr);
unsigned StrHexNum(char *ptr, UNS8 bytes);
unsigned tohex(UNS16 number);
char tolower(char cval);
void puth(unsigned long num, int width);
void puti(unsigned long num);
void htoa(unsigned long n, char *s);
void InitCom1(char portnum);
char GetAddr();



#endif // D_serial
