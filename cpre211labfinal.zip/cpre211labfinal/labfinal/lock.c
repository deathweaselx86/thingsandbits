// lock.c : Main C source file for Cpr E 211 labs
//////////////////////////////////////////////////////////////
// Authors:		Alex McLaren			mcalex9@iastate.edu
//				Jessica Ross			rossjr@iastate.edu
// Both of us came in and worked on this together.
// Lab:			12-2 PM, Thursday
//	
// TA:			Cpr E 211 TA
//
//
// Instructor:	Cpr E 211 Instructor
//  /////////////////////////////////////////////////////////////
// Description: Lab 3, the sprayer lock. Implements a digital
// lock to open a sprayer. Also includes password changing.
//   
//////////////////////////////////////////////////////////////

// Include Files
//////////////////////////////////////////////////////////////

#include "QTerm.h"			// Accessing the QTerm-J10 Terminal
#include "Defines.h"
#include "serial.h"			// Accessing the serial ports
#include "PPC_Support.h"	// msleep & miscellaneous functions

#define LOOPSLEEP 200

char getInput();

main()
{
	/* howManyEntered = a character counting index number 
		myChar = the character that keeps track of what we have just entered normally
		myPassChar = the character that keeps track of what we have entered for our password
		myPassword = the password ...*/
    int howManyEntered=0; 
    char myChar, myPassChar, open='n', myPassword[] ="#05C211"; 
    char *myInput = (char *)IO_DIGITAL_INPUT_KEYPAD; //pointer to input stream from the keypad
    char *myStatus = (char *)IO_DIGITAL_OUTPUT_LED1; //pointer our LED screen that records whether or not our lock's open
    char *myReset = (char *)IO_DIGITAL_INPUT_DIP_1; //Our reset switch
    
    
    LCD_Init(); 
    *myStatus=*myStatus|0x01; /* Turning OFF but 0 of the LED. It seems to default on */    LCD_PutString("Password: ");
    while(1) //Forever...
    {
    	//If a button is pressed
    	if(*myInput&(0x10))
    	  {
    	  	myChar = getInput(); //get the input and translate it into a character
  			if(myChar !=0) //If input is a valid character
  			{
    	  		if((myChar == '*')&&(open == 'y')) //if it's a '*' and the box is unlocked
    	  		{
    	  		LCD_Clear(); /* clear the LED and prepare to take a new password */
    	  	 	LCD_PutString("Enter new password\r");
    	  	 	while(howManyEntered<7) // We have limited the length of the password to 6 characters, but
    	  	 		{						//it might be more. Not sure.
    	  	 			if(*myInput&0x10)//Again, if a button's pressed
    	  	 			{
    	  	 				myPassChar = getInput();
    	  	 				if(myPassChar != 0)//we only record VALID values, else keep looping
    	  	 				{
    	  	 					myPassword[howManyEntered] = myPassChar; //We are changing the password character by character
    	 	 					msleep(LOOPSLEEP);							//We would print a character to the screen, but that's
    	 	 					howManyEntered++;				//unrealistic. 
    	 					}
    	 				}	
    	  			}	
    	 	 		
    	  			LCD_Clear(); //Wipe that slate.
    	 	 		*myStatus=*myStatus|0x01; //relock the box
    	 	 		open = 'n'; 
    		 		howManyEntered=0; //make sure we can take in input again */
    	 	 	}
    	 	 	else //we're trying to open the box
    	 	 	{	 
    	  			LCD_PutChar(myChar); //Write the character to the screen so we can see it
    	  			msleep(LOOPSLEEP);  //and nap a while to debounce
    				//If the input is correct, keep accepting new input
				  	if(myPassword[howManyEntered] == myChar) //if the character is correct, move our position in the
		 		  		howManyEntered++;				//string up
		 		 	else
		 		 	{	
		 		 	 	howManyEntered = 0; //else, reset our position
		 		 	
		 		 	}
		 		 }
				} 		
			}
			if(howManyEntered == strlen(myPassword)) //If we are at the end of the string and we haven't entered anything
				{								// wrong [yet]
					*myStatus = *myStatus&0xFE; //open the lock
					open = 'y'; 			
					howManyEntered=0;
    	 	 	}
    	 	 				
			if((~*myReset&0x01)&&(open=='y'))	//if we have flipped the reset switch of DIP 1,
				{	
				    *myStatus = *myStatus|0x01; //also reset the lock
				    open = 'n';
				    howManyEntered=0; //Apparently this also resets our position in the password string. A true reset!
 				  }
				}
				
	
	return 0;
}

char getInput()
{
	
	char * myInput = (char *)IO_DIGITAL_INPUT_KEYPAD;
	
	msleep(100); //Trying to avoid bounce
	/* This really long series of ifs translates the output of the keypad to
		characters usable to write to the LED.
		The schema for translating looks like this:
		
		16+...           translates to 
		0  1  2   3						1 2 3 A
		4  5  6   7						4 5 6 B
		8  9  10  11					7 8 9 C
		12 13 14  15					* 0 # D
	
													*/	
	if(*myInput == (char)16+15)
		return 'D';
	
	if(*myInput == (char)16+14)
		return '#';
	
	if(*myInput == (char)16+13)
		return '0';
	
	if(*myInput == (char)16+12)
		return '*';
	
	if(*myInput == (char)16+11)
		return 'C';
	
	if(*myInput == (char)16+10)
		return '9';
	
	if(*myInput == (char)16+9)
		return '8';
	
	if(*myInput == (char)16+8)
		return '7';
	
	if(*myInput == (char)16+7)
		return 'B';
	
	if(*myInput == (char)16+6)
		return '6';
	
	if(*myInput == (char)16+5)
		return '5';
	
	if(*myInput == (char)16+4)
		return '4';
	
	if(*myInput == (char)16+3)
		return 'A';
	
	if(*myInput == (char)16+2)
		return '3';
	
	if(*myInput == (char)16+1)
		return '2';
	
	if(*myInput == (char)16)
		return '1';

	return 0; /* It should never get here, but we put this in anyway. If it returns 0, there's a problem.
				I think this is the origin of the spaces we get when the user holds the button too long, but
				not long enough for the button to register the next cycle */

}