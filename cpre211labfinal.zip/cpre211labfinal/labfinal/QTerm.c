// QTerm.c : Special files for QTerm display on PowerPC education board
///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2001	Iowa State University 
// All rights reserved.
//
// Department of Electrical & Computer Engineering
// Iowa State University
// Ames, IA 50010
//
// http://www.ee.iastate.edu/
//
///////////////////////////////////////////////////////////////////////////////
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
// 3. All advertising materials mentioning features or use of this software
//    must display the following acknowledgement:
// 		This product includes software developed by the Iowa State 
//      University.
// 4. Neither the name of the University nor of the Research Group may be used
//    to endorse or promote products derived from this software without
//    specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////////

#include "Defines.h"
#include "serial.h"
#include "QTerm.h"
#include "PPC_Support.h"

///////////////////////////////////////////////////////////////////////////////
// void	LCD_Init 	()
//
// Initialize the LCD screen for operation (need to call only once)
//
//  - Set SCI2 to 9600 baud for communicating with the QTerm
//	- Reset the LCD screen (power-up defaults)
//	- Clear out the serial buffer on SCI2 for the PowerPC chip
//	- Clear the LCD screen
//

void	LCD_Init 	()
{
	InitCom(SERPORT_LCD);

	LCD_Reset ();
	
	msleep(500);
	
	LCD_ClearBuffer();
	LCD_Clear ();	

	Set_LCD_AutoWrap(1);		// AutoWrap ON
	Set_LCD_AutoScroll(0);		// AutoScroll OFF
	Set_LCD_AutoLineFeed(1); 	// AutoLineFeed ON
	Set_LCD_Contrast(85);		// Set Contrast to 85%

	Set_LCD_Backlight(LCD_BACKLIGHT_OFF);	// Turn LCD Backlight OFF
}

///////////////////////////////////////////////////////////////////////////////

void	LCD_Clear	()
{
	LCD_PutChar(QTERM_ESCAPE);
	LCD_PutChar(QTERM_CLEAR_SCREEN);
}	

///////////////////////////////////////////////////////////////////////////////

void	LCD_Reset	()
{
	LCD_PutChar(QTERM_ESCAPE);
	LCD_PutChar(QTERM_RESET);
}	

///////////////////////////////////////////////////////////////////////////////
// void		LCD_MoveCursor		(int nX, int nY)
//
//	Move cursor relative to current position
//
// Return Values:
//	None
//

void	LCD_MoveCursor		(int nX, int nY)
{
	int j;

	if(nX > 0)
	{
		for(j=0; j<nX; j++)
		{
			LCD_PutChar(QTERM_ESCAPE);
			LCD_PutChar(QTERM_CURSOR_RIGHT);
		}
	}
	else
	{
		for(j=nX; j<0; j++)
		{
			LCD_PutChar(QTERM_ESCAPE);		
			LCD_PutChar(QTERM_CURSOR_LEFT);
		}
	}
	
	if(nY > 0)
	{
		for(j=0; j<nY; j++)
		{
			LCD_PutChar(QTERM_ESCAPE);
			LCD_PutChar(QTERM_CURSOR_DOWN);
		}
	}
	else
	{
		for(j=nY; j<0; j++)
		{
			LCD_PutChar(QTERM_ESCAPE);		
			LCD_PutChar(QTERM_CURSOR_UP);
		}
	}	
}

///////////////////////////////////////////////////////////////////////////////
// void	LCD_GotoXY			(int nX, int nY)
//
//	Go to the specified X,Y position on the display
//

void	LCD_GotoXY			(int nX, int nY)
{
	char	nOutChar;

	// Upper and lower bounds of display

	if(nX > 3)
		nX = 3;
		
	if(nX < 0)
		nX = 0;
		
	if(nY > 19)
		nY = 19;
		
	if(nY < 0)
		nY = 0;
		
	LCD_PutChar(QTERM_ESCAPE);
	LCD_PutChar(QTERM_SET_POS);
	
	nOutChar = '@';
	nOutChar = nOutChar + (char) nX;
	LCD_PutChar(nOutChar);
	
	nOutChar = '@';
	nOutChar = nOutChar + (char) nY;
	LCD_PutChar(nOutChar);	
}

///////////////////////////////////////////////////////////////////////////////

void		LCD_ClearBuffer		()
{
	int		nPortNum;
	
	nPortNum = ioport;
	
	while(!SerialReady(SERPORT_LCD))
	{
		ReadSerialPort(SERPORT_LCD);
	}	
	
	ioport = nPortNum;
}

///////////////////////////////////////////////////////////////////////////////
//
//
// Warning:	Removes all input from buffer

void		LCD_GetPos			(int * pX, int * pY)
{
	char		cX;
	char		cY;

	// Clean out pending buffer

	LCD_ClearBuffer ();
	
	LCD_PutChar(QTERM_ESCAPE);
	LCD_PutChar(QTERM_QUERY_POS);

	while(SerialReady(SERPORT_LCD))
	{ }	
	
	cX = ReadSerialPort(SERPORT_LCD);	
	
	*pX = cX - '@';

	while(SerialReady(SERPORT_LCD))
	{ }	
	
	cY = ReadSerialPort(SERPORT_LCD);	
	
	*pY = cY - '@';
}

///////////////////////////////////////////////////////////////////////////////
//
//
// Warning:	Removes all input from buffer

char		LCD_GetCharAtPos	()
{
	// Clean out the pending buffer

	LCD_ClearBuffer ();

	LCD_PutChar(QTERM_ESCAPE);
	LCD_PutChar(QTERM_QUERY_CHAR);

	while(SerialReady(SERPORT_LCD))
	{ }	
	
	return ReadSerialPort(SERPORT_LCD);
}

///////////////////////////////////////////////////////////////////////////////

void		LCD_PutChar			(char cOut)
{
	int		nOldPort;
	
	nOldPort = ioport;
	
	while(putchar(cOut))
	{ }
	
	ioport = nOldPort;
}

///////////////////////////////////////////////////////////////////////////////

void		LCD_PutString		(char * pString)
{
	int		nOldPort;
	
	nOldPort = ioport;
	
	puts(pString);
	
	ioport = nOldPort;
}

///////////////////////////////////////////////////////////////////////////////
// Automatic modes

///////////////////////////////////////////////////////////////////////////////

void		Set_LCD_AutoWrap		(char bWrap)
{
	LCD_PutChar(QTERM_ESCAPE);

	LCD_PutChar(QTERM_AUTO_WRAP);

	if(bWrap)
		LCD_PutChar('A');
	else
		LCD_PutChar('@');		
}

///////////////////////////////////////////////////////////////////////////////

void		Set_LCD_AutoScroll		(char bScroll)
{
	LCD_PutChar(QTERM_ESCAPE);

	LCD_PutChar(QTERM_AUTO_SCROLL);

	if(bScroll)
		LCD_PutChar('A');
	else
		LCD_PutChar('@');		

}

///////////////////////////////////////////////////////////////////////////////

void		Set_LCD_AutoLineFeed	(char bLineFeed)
{
	LCD_PutChar(QTERM_ESCAPE);

	LCD_PutChar(QTERM_AUTO_LINEFEED);

	if(bLineFeed)
		LCD_PutChar('A');
	else
		LCD_PutChar('@');		
}

///////////////////////////////////////////////////////////////////////////////
// Misc. commands

///////////////////////////////////////////////////////////////////////////////

void		Set_LCD_Contrast		(char nLevel)
{
	char contrastLevel;
	
	// Specify a level from 0-100% (0=Min,100=Max)
	LCD_PutChar(QTERM_ESCAPE);
	
	LCD_PutChar(QTERM_SET_CONTRAST);
	
	// calculate the contrast level
	// contrastLevel = offset + ((level between 0 - 100) * (minimum value)) / 100

	contrastLevel = 64 + (nLevel * 63) / 100;
	
	LCD_PutChar(contrastLevel);

}

///////////////////////////////////////////////////////////////////////////////

void		Set_LCD_Backlight		(char nLight)
{
	switch(nLight)
	{
		case LCD_BACKLIGHT_ON:
			LCD_PutChar(QTERM_ESCAPE);
			LCD_PutChar(QTERM_BACKLIGHT);
			LCD_PutChar('A');
			break;
		case LCD_BACKLIGHT_OFF:
			LCD_PutChar(QTERM_ESCAPE);
			LCD_PutChar(QTERM_BACKLIGHT);
			LCD_PutChar('@');		
			break;
		case LCD_BACKLIGHT_TOGGLE:
			LCD_PutChar(QTERM_ESCAPE);
			LCD_PutChar(QTERM_BACKLIGHT);
			LCD_PutChar('B');		
			break;
		default:
			break;
	}
}

///////////////////////////////////////////////////////////////////////////////

void		Set_LCD_CursorType		(char nType)
{
	switch(nType)
	{
		case LCD_CURSOR_NONE:
			LCD_PutChar(QTERM_ESCAPE);
			LCD_PutChar(QTERM_SET_CURSOR_MODE);
			LCD_PutChar('@');		
			break;
		case LCD_CURSOR_LINE:
			LCD_PutChar(QTERM_ESCAPE);
			LCD_PutChar(QTERM_SET_CURSOR_MODE);			
			LCD_PutChar('A');		
			break;
		case LCD_CURSOR_BLOCK:
			LCD_PutChar(QTERM_ESCAPE);
			LCD_PutChar(QTERM_SET_CURSOR_MODE);
			LCD_PutChar('B');		
			break;
		case LCD_CURSOR_FULL:
			LCD_PutChar(QTERM_ESCAPE);
			LCD_PutChar(QTERM_SET_CURSOR_MODE);
			LCD_PutChar('C');		
			break;
		default:
			break;
	}
}

