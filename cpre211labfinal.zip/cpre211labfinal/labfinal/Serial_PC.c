// Serial_PC.c : Source code for serial link to PC
///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2001	Iowa State University 
// All rights reserved.
//
// Department of Electrical & Computer Engineering
// Iowa State University
// Ames, IA 50010
//
// http://www.ee.iastate.edu/
//
///////////////////////////////////////////////////////////////////////////////
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
// 3. All advertising materials mentioning features or use of this software
//    must display the following acknowledgement:
// 		This product includes software developed by the Iowa State 
//      University.
// 4. Neither the name of the University nor of the Research Group may be used
//    to endorse or promote products derived from this software without
//    specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////////

#include "Defines.h"
#include "serial.h"
#include "Serial_PC.h"

///////////////////////////////////////////////////////////////////////////////
// void	PC_Init 	()
//
// Initialize the LCD screen for operation (need to call only once)
//
//  - Set SCI1 to 9600 baud for communicating with the PC
//	- Clear out the serial buffer on SCI1 for the PowerPC chip
//

void	PC_Init 	()
{
	InitCom(SERPORT_PC);

	PC_ClearBuffer();
}

///////////////////////////////////////////////////////////////////////////////

void	PC_ClearBuffer		()
{
	int		nPortNum;
	
	nPortNum = ioport;
	ioport = SERPORT_PC;	
	
	while(!SerialReady(SERPORT_PC))
	{
		ReadSerialPort(SERPORT_PC);
	}	
	
	ioport = nPortNum;
}

///////////////////////////////////////////////////////////////////////////////

void	PC_PutChar			(char cOut)
{
	int		nOldPort;
	
	nOldPort = ioport;
	ioport = SERPORT_PC;
	
	while(putchar(cOut))
	{ }
	
	ioport = nOldPort;
}

///////////////////////////////////////////////////////////////////////////////

void	PC_PutString		(char * pString)
{
	int		nOldPort;
	
	nOldPort = ioport;
	ioport = SERPORT_PC;
	
	puts(pString);
			
	ioport = nOldPort;
}

char	PC_GetChar ()
{
	int		nOldPort;
	char	returnChar;

	nOldPort = ioport;		// setup temp var for old port #
	ioport = SERPORT_PC;	// set ioport to the PC serial port COM2
	
	// set the return char to call the GetSByte function that gets in one byte
	// from the serial port.  GetSByte is a blocking call
	returnChar = GetSByte();

	// reset the ioport to the old port #	
	ioport = nOldPort;
	
	// return the char read in from the PC	
	return ( returnChar );
}

///////////////////////////////////////////////////////////////////////////////

char *	PC_GetString ()
{
	int		nOldPort;
	char * 	rtnString;
	
	nOldPort = ioport;		// setup temp var for old port #
	ioport = SERPORT_PC;	// set ioport to the PC serial port COM2
	
	// call the serial blocking receive function to read in a string
	GetString();			
	
	// set the return string to the global buffer where GetString put the 
	// 	received string from the PC
	rtnString = (char * ) &inbuf[Rcount];
				
	// reset the ioport to the old port #				
	ioport = nOldPort;
	
	// return the string read in from the PC
	return ( rtnString );
}
