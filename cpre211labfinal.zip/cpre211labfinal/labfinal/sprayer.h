//sprayer.h : Main C source file for Cpr E 211 lab 5
//////////////////////////////////////////////////////////////
// Authors:		Alex McLaren			mcalex9@iastate.edu
//				Jessica Ross			rossjr@iastate.edu
//
// Lab:			12-2 PM, Thursday
//	
// TA:	Qiang Qiu		
//
// Instructor:	Tyagi
//
//////////////////////////////////////////////////////////////
// Description:
//
//  header file for the sprayer functions for lab 5 sprayers
//////////////////////////////////////////////////////////////
/* Please see sprayer.c for detailed comments. */

void light_even(char* arm); //lights even bits
void light_odd(char* arm); //lights odd bits
void light_none(char* arm); //lights no bits
void light_all(char* arm); //lights all bits
void all1(char* arm); // The "All" timed spray pattern functions
void all2(char* arm);// for each arm
void outer1(char* arm);//The "Outer" timed spray pattern functions for
void outer2(char* arm); //each arm
void inner1(char* arm); //The "Inner" timed spray pattern functions for
void inner2(char* arm);//each arm
void test1(char* arm); //The "Test" timed spray pattern functions for 
void test2(char* arm); //each arm

