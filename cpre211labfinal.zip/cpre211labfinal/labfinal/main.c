// main.c : Main C source file for Cpr E 211 labs
//////////////////////////////////////////////////////////////
// Authors:		Lab member 1			lab1@iastate.edu
//				Lab member 2			lab2@iastate.edu
//
// Lab:			7-9 AM, Monday
//	
// TA:			Cpr E 211 TA
//
// Instructor:	Cpr E 211 Instructor
//
//////////////////////////////////////////////////////////////
// Description:
//
//   Blank main file for use in C labs
//////////////////////////////////////////////////////////////

// Include Files
//////////////////////////////////////////////////////////////

#include "QTerm.h"			// Accessing the QTerm-J10 Terminal
#include "serial.h"			// Accessing the serial ports
#include "PPC_Support.h"	
#include "defines.h"

//////////////////////////////////////////////////////////////
// Prototype for assembly function linkage

asm void StartAsm();		// Place as many linkages as necessary

//////////////////////////////////////////////////////////////
// asm void JumpAsm ()
//
// Dummy function - Simply branches into the assembly file as
//  necessary.
//
// This may be repeated as necessary
//
//	Do not use assembly style comments in this code portion
//

asm void JumpAsm ()
{
	fralloc

	bl	StartAsm
	
	frfree
	
	blr						// Branch to link register location
							//   i.e. return from function
}



#define LOOPSLEEP 200


void displayMenu();
void displaySettings();
void Clear_Buffers (unsigned short* QTBuffer, unsigned short* HTBuffer);
void Clear_QTerm(unsigned char dip_switch, unsigned char bit);
asm void StartAsm();

main()
{
	//////////////////////////////////////////////////////////
	// Place your code in here
	int howManyEntered=0, locked = 1, myPasswordSize=7; 
    char myChar, myPassChar, *myPassword;  
 	char *myDisp = (char *)IO_DIGITAL_OUTPUT_7SEG; //address of seven segment display
 	char *myStatus2 = (char *)IO_DIGITAL_OUTPUT_LED2;
    char *myStatus1 = (char *)IO_DIGITAL_OUTPUT_LED1; //pointer our LED screen that records whether or not our lock's open
	*myStatus1=0xFF;  //turning off the left and right LEDs
	*myStatus2=0xFF; 
	*myDisp = *myDisp&0x0; //turning off seven segment display
	myPassword = (char *)malloc(sizeof(char)*8); // initial stack allocation of our default password plus
	strcpy(myPassword,"#05C211"); //default password
	LCD_Init();
	while(1) //Forever...
	{
		if(locked)
		{
			LCD_PutString("Enter Password:");
			*myStatus1 = 0xFF; //turning off the LEDs in anticipation of using the sprayer function
			*myStatus2 = 0xFF; 
		}
			
		while(locked)
		{
			//If a button is pressed
    		if(!SerialReady(2))
    	 	 {
    	  		myChar = ReadSerialPort(2); //get the input and translate it into a character
  				if(myChar !=0) //If input is a valid character
  				{
    	  				
    	 	 			
    	  					LCD_PutChar(myChar); //Write the character to the screen so we can see it
    	  					msleep(LOOPSLEEP);  //and nap a while to debounce
    						//If the input is correct, keep accepting new input
						  	if(myPassword[howManyEntered] == myChar) //if the character is correct, move our position in the
		 				  		howManyEntered++;				//string up
		 				 	else	
		 				 	 	howManyEntered = 0; //else, reset our position
		 				 	
		 		 }
			  } 		
			
			if(howManyEntered == myPasswordSize) //If we are at the end of the string and we haven't entered anything
				{								// wrong [yet]
					LCD_Clear();
					locked = 0;			//open the lock so we can access the main menu
					howManyEntered=0;
    	 	 	}
    	 	 				
		}
				
			if(!locked)
			{	
				LCD_Clear();
				displayMenu();
			}
			
			while(!locked)
			{
				//functional stuff goes here
			 	char myOption='0';
				if(!SerialReady(2))
				{
					myOption = ReadSerialPort(2);
					switch(myOption)
						{
							case '1':		//relock
											locked = 1;
											LCD_Clear(); //this will go back to the locked part
											break;
							case '2':		//change password
    	  									LCD_Clear(); /* clear the LED and prepare to take a new password */
    	  	 								LCD_PutString("Enter new password\r");
    	  	 								myPassChar = 0;
    	  	 								howManyEntered = 0;
    	  	 								myPasswordSize=0;
    	  	 								while(myPassChar != QTERM_ENTER_KEY) //Enter key terminates password
    	  	 								{									
    	  	 									if(!SerialReady(2))//Again, if a button's pressed
    	  	 									{
    	  	 										myPassChar = ReadSerialPort(2);
    	  	 										if((myPassChar != 0)&&(myPassChar != QTERM_ENTER_KEY))//we only record VALID values, else keep looping
    	  	 										{
    	  	 											if(howManyEntered > sizeof(myPassword)) 
    	  	 												realloc(myPassword,sizeof(myPassword)+1); //reallocating according to the size of howManyEntered
    	  	 											if(howManyEntered < sizeof(myPassword))	
    	  	 												realloc(myPassword,howManyEntered+1); //deallocating extra space not used by the password yet
    	  	 											myPassword[howManyEntered] = myPassChar;
    	  	 											howManyEntered++; 
    	  	 											myPasswordSize++;
    	 	 											msleep(LOOPSLEEP);							
    	 											}
    	 										}	
    	  									}	
    	 	 		
    	  									LCD_Clear(); //Wipe the slate.
    	  									LCD_PutString("Password accepted.\r");
    	 	 								msleep(1000);
    	 	 								LCD_Clear();
    		 								howManyEntered=0; //make sure we can take in input again */
    		 								displayMenu();
											break;
										
						case '3':		//run sprayer
										spray(); //goes to sprayer function
										displayMenu();
										break;
						case '4':		//communication system
										PC_Init();   //The following is preparation for asm communication system
										LCD_Clear();
										msleep(LOOPSLEEP); //making sure everything settles down
										JumpAsm(); //To the ASM !
										displayMenu();
										locked=0;
										break;
						case '5':		//LCD Backlight toggle
										displaySettings(); 
										displayMenu();
										break;
			
					}
			
				}
			}
		}

	free(myPassword); //deallocate space taken up by password. Not really required because we can't
	return 0;			//properly turn off the box
}
void displaySettings()
{
	char myOption='0'; //input variable
	static int myContrast=-1; //initial value for state variable for contrast
	static char myBacklight=0; //initial value for state variable for backlight
	LCD_Clear(); //the following is the actual menu part
	LCD_PutString("Settings\r");  
	LCD_PutString("1)Backlight\r");
	LCD_PutString("2)Contrast\r");
	while(myOption == '0') //this is the input system that changes contrast, backlight, or just returns
	{
		if(!SerialReady(2))
			myOption = ReadSerialPort(2);
		if(myOption == '2')
		{
			myContrast = (myContrast+1)%4;
			switch(myContrast)
			{
				case 0:			Set_LCD_Contrast(70); //much lighter than this is very very hard to read	
								break;
				case 1:			Set_LCD_Contrast(80); //this is okay
								break; 
				case 2:			Set_LCD_Contrast(90); //this is much darker 
								break;
				case 3:			Set_LCD_Contrast(100); //I think that this is the maximum value
								break;
			}
			
		}
		if(myOption == '1')
		{
			myBacklight = myBacklight+1;
			Set_LCD_Backlight(myBacklight%3); //the backlight has three settings...
		}
			//if myOption != 2,1, then it returns to the main menu
	}	
}	

void displayMenu()
{
	//If we put this in the main loop above, there's some unpleasant refresh consequences
	LCD_Clear();
	//display menu
	LCD_PutString("1)Lock   5)Settings\r");
	LCD_PutString("2)Change Password\r");
	LCD_PutString("3)Run Sprayer\r");
	LCD_PutString("4)Communicator\r");
}


//The next two functions are functions that are called from assembly for the communication mode
void Clear_QTerm(unsigned char dip_switch, unsigned char bit)
{ 
	static int done=0;
	if(dip_switch == bit)
	 {
	  LCD_Clear ();
	  LCD_Init();
	  done = 1;
	 } 
	return ;
	
}		

void Clear_Buffers (unsigned short* QTBuffer, unsigned short* HTBuffer)
{
	*QTBuffer = 0;
	QTBuffer = QTBuffer +2;
	*QTBuffer = 0;
	
	*HTBuffer = 0;
	HTBuffer = HTBuffer +2;
	*HTBuffer = 0;
	LCD_Clear();
	LCD_Init();

return;
}

