// main.c : Main C source file for Cpr E 211 labs
//////////////////////////////////////////////////////////////
// Authors:		Owen Koch			okoch@iastate.edu
//
// Lab:			12-2 PM, Thursday
//	
// TA:			Qiang Qiu
//
// Instructor:	Zhao Zhang 
//
//////////////////////////////////////////////////////////////
// Description:
//
//   sprayer controls off of DIP 1 printed to LED 1 & 2
//////////////////////////////////////////////////////////////



#include "QTerm.h"			// Accessing the QTerm-J10 Terminal
#include "serial.h"			// Accessing the serial ports
#include "PPC_Support.h"	// msleep & miscellaneous functions
#include "defines.h"		// addressing io devices

char l_custom_length = -1; //length of left custom spray pattern
char r_custom_length = -1; //length of right custom spray pattern
char left_custom_pattern[42]; //left custom user defined spray pattern
char right_custom_pattern[42];//right custom user defined spray pattern


void main_spray (char left_switch, char right_switch);  //run the spray after initial conditions set
void custom_define(char side);							//define the custom patterns
void update_BARs(char pattern_LED1,char pattern_LED2);	//print to the LED bars

void spray ()  // all that is called from the menu.  allows it to be VERY modular
{
	char temp[80];
	char type;
	char left_switch, right_switch;
	char choice;
	
	update_BARs(0x00, 0x00); // clear the LEDs
	LCD_Init();
	LCD_Clear();
	
	sprintf(temp, "Left Spray Type?\r1)Test   2)All\r3)Inner  4)Outer\r5)Custom 6)Cancel\r");
	LCD_PutString(temp); //Left menu
	
	LCD_ClearBuffer (); type=-1;  //disreguard all previous junk
	
	while(type < '1' || type > '6') 
	{	
		while(SerialReady(SERPORT_LCD)) { }	  //get the user input
		type = ReadSerialPort(SERPORT_LCD);
	}
			
	if(type=='1') left_switch='t';
	else if (type=='2') left_switch='a';
	else if (type=='3') left_switch='i';	//determine user choice
	else if (type=='4') left_switch='o';
	else if (type=='5') 
	{
		left_switch='c';
		if( l_custom_length == -1)	custom_define('l');
		else	
		{
			LCD_Clear();				//  if there is something previously
			LCD_PutString("1)Use Existing\r2)Define New\r"); //let the user use it again
		
			LCD_ClearBuffer (); choice=-1;
	
			while(choice != '1' && choice != '2') 
			{	
				while(SerialReady(SERPORT_LCD)) { }	
				choice = ReadSerialPort(SERPORT_LCD);
			}
			if(choice == '2') 
			{
				r_custom_length=1;
				right_custom_pattern[0]=0x00;
				custom_define('l'); // the user can choose to build a new custom
			}	
		}	
	}
	else
	{
		update_BARs(0x00,0x00);
		return;
	}	
	
	LCD_Clear();
	
	sprintf(temp, "Right Spray Type?\r1)Test   2)All\r3)Inner  4)Outer\r5)Custom 6)Cancel\r");
	LCD_PutString(temp);  //right menu
	
	LCD_ClearBuffer (); type=-1;	//disreguard previous junk
	
	while(type < '1' || type > '6') //menu selection ranges
	{		
		while(SerialReady(SERPORT_LCD)) { }	
		type = ReadSerialPort(SERPORT_LCD);
	}
	
//	LCD_ClearBuffer ();
		
	if(type=='1') right_switch='t';
	else if (type=='2') right_switch='a';	//figure what the user chooses
	else if (type=='3') right_switch='i';
	else if (type=='4') right_switch='o';
	else if (type=='5') 
	{
		right_switch='c';
		if( r_custom_length == -1)	custom_define('r');  //never used custom, so define it
		else	
		{
			LCD_Clear();
			LCD_PutString("1)Use Existing\r2)Define New\r");  //custom already defined, let user decide
		
			LCD_ClearBuffer (); choice=-1;
	
			while(choice != '1' && choice != '2') 
			{	
				while(SerialReady(SERPORT_LCD)) { }	
				choice = ReadSerialPort(SERPORT_LCD);
			}
			if(choice == '2') 
			{
				r_custom_length=1;
				right_custom_pattern[0]=0x00;
				custom_define('r');  // user chose to define a new right custom
			}
		}	

	}
	else 	
	{
		update_BARs(0x00,0x00);	//possible return to main menu.  clear the LED's
		return;
	}	
	main_spray(left_switch, right_switch);  // starting conditions defined, do the spray
	
	update_BARs(0x00,0x00);
	return;
	
}	


void main_spray (char left_switch, char right_switch)  //initial conditions set, actually start spraying now
{	
	char l_test_state=0, l_inner_state=0, l_outer_state=0, l_all_state=0, l_custom_state=0; //keep track of the left sprayer state variables
	char r_test_state=0, r_inner_state=0, r_outer_state=0, r_all_state=0, r_custom_state=0; //keep track of the right sprayer state variables
	
	char test_pattern[]= {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};  //array of test patterns
	char inner_pattern[]={0x00,0x00,0x10,0x10,0x30,0x30,0x70,0x70,0xF0,0xF0}; //array of inner patterns
	char outer_pattern[]={0x00,0x00,0x08,0x08,0x0C,0x0C,0x0E,0x0E,0x0F,0x0F}; //array of outer patterns
	char all_pattern[]=	 {0x55,0x55,0xAA,0xAA,0xFF,0xFF,0x00,0x00,0x00,0x00}; // array of all patterns


	char pattern_LED1 = 0x00;    
	char pattern_LED2 = 0x00;
	char left_test_dir=0;
	char right_test_dir=0;
	
	char fKeys=0; // bit1=f1, bit2=f2 ect
	char temp; // for LCD_GetChar()
	LCD_Clear();
	LCD_PutString("F1&F2 For Left\rF3&F4 For Right\rF5 Exits");
	LCD_ClearBuffer();
	
	//implement F1 to scroll through left patterns one way
	//implement F2 to scroll through left patterns the other way
	//implement F3 to scroll through right patterns one way
	//implement F4 to scroll through right patterns the other way
	//implement F5 to exit.

	while(!(fKeys&0x20))	//Determine F keys hit
	{	if(!SerialReady(SERPORT_LCD)) temp = ReadSerialPort(SERPORT_LCD);
		else 	{ fKeys = 0x00;		 temp = 0; }
		if( temp == QTERM_F1_KEY ) fKeys = 0x02;
		if( temp == QTERM_F2_KEY ) fKeys = 0x04;
		if( temp == QTERM_F3_KEY ) fKeys = 0x08;
		if( temp == QTERM_F4_KEY ) fKeys = 0x10;
		if( temp == QTERM_F5_KEY ) 
		{
			fKeys = 0x20;
			pattern_LED1=0x00;
			pattern_LED2=0x00;
		}	
	
		if( (fKeys&0x02) == 0x02 ) //Left pattern positive scroll
		{	
			if(left_switch=='t') left_switch='a';
			else if(left_switch=='a') left_switch='i';
			else if(left_switch=='i') left_switch='o';
			else if(left_switch=='o') 
				{
					if (l_custom_length != -1 ) left_switch='c'; //goto custom only if it is defined
				 	else				 left_switch='t';
				}
			else  left_switch='t'; // if(left_switch=='c')	 	
		}
	
	
		else if((fKeys&0x04) == 0x04 ) //Left pattern negative scroll
		{	
			if(left_switch=='c') left_switch='o';
			else if(left_switch=='o') left_switch='i';
			else if(left_switch=='i') left_switch='a';
			else if(left_switch=='a') left_switch='t';
			else  // if(left_switch=='t') 
			{
				if (l_custom_length != -1 ) left_switch='c'; //goto custom only if it is defined
			 	else				 left_switch='o';
			}
		}
		
	
		else if((fKeys&0x08) == 0x08) //Right pattern positive scroll
		{	
			if(right_switch=='t') right_switch='a';
			else if(right_switch=='a') right_switch='i';
			else if(right_switch=='i') right_switch='o';
			else if(right_switch=='o') 
				{
					if (r_custom_length != -1 ) right_switch='c'; //goto custom only if it is defined
				 	else				 right_switch='t';
				}
			else  right_switch='t'; // if(right_switch=='c')	 	
		}
		
		
		else if((fKeys&0x10) == 0x10 ) //Right pattern negative scroll
		{	
			if(right_switch=='c') right_switch='o';
			else if(right_switch=='o') right_switch='i';
			else if(right_switch=='i') right_switch='a';
			else if(right_switch=='a') right_switch='t';
			else  // if(right_switch=='t') 
			{
				if (r_custom_length != -1 ) right_switch='c'; //goto custom only if it is defined
			 	else				 right_switch='o';
			}
		}

		
/////////////// Left Sprayer \\\\\\\\\\\\\\\\\\ Left side pattern.  switch to the pattern, proceede through array

		if(left_switch=='t') //left=test
		{
			pattern_LED2=test_pattern[l_test_state];//get pattern from array
			if(l_test_state==7) left_test_dir=1;
			if(l_test_state==0) left_test_dir=0;	//define direction through array
			if(left_test_dir==0) l_test_state++;
			else			 	 l_test_state--;	//define new position in array
		}	
		
		else if(left_switch=='o')
		{
			pattern_LED2=outer_pattern[l_outer_state];//get pattern from array
			l_outer_state++;
			if(l_outer_state==10) l_outer_state=0;//define new position in array
		}

		else if(left_switch=='i')
		{
			pattern_LED2=inner_pattern[l_inner_state];//get pattern from array
			l_inner_state++;
			if(l_inner_state==10) l_inner_state=0;//define new position in array
		}	

		else if(left_switch=='a')
		{
			pattern_LED2=all_pattern[l_all_state];//get pattern from array
			l_all_state++;
			if(l_all_state==10) l_all_state=0;		//define new position in array		
		}

		else //left_switch=='c'
		{
			pattern_LED2=left_custom_pattern[l_custom_state];//get pattern from array
			l_custom_state++;
			if(l_custom_state==l_custom_length) l_custom_state=0;	//define new position in array			
		}		
		
		
//////////////// Right sprayer \\\\\\\\\\\\\\\\

	 	if(right_switch=='t') 
		{
			pattern_LED1=test_pattern[r_test_state];//get pattern from array
			if(r_test_state==7) right_test_dir=1;
			if(r_test_state==0) right_test_dir=0;//define direction through array
			if(right_test_dir==0) r_test_state++;
			else			 	 r_test_state--; //define new position in array
		}	
		
		else if(right_switch=='o')
		{
			pattern_LED1=outer_pattern[r_outer_state];//get pattern from array
			r_outer_state++;
			if(r_outer_state==10) r_outer_state=0;//define new position in array
		}

		else if(right_switch=='i')
		{
			pattern_LED1=inner_pattern[r_inner_state];//get pattern from array
			r_inner_state++;
			if(r_inner_state==10) r_inner_state=0;//define new position in array
		}

		else if(right_switch=='a')
		{
			pattern_LED1=all_pattern[r_all_state];//get pattern from array
			r_all_state++;
			if(r_all_state==10) r_all_state=0;		//define new position in array		
		}

		else //right_switch=='c'
		{
			pattern_LED1=right_custom_pattern[r_custom_state];//get pattern from array
			r_custom_state++;
			if(r_custom_state==r_custom_length) r_custom_state=0;//define new position in array
		
		}						

		update_BARs(pattern_LED1,pattern_LED2); //print the updated left and right patterns
		msleep(200); //wait between updates 1/4 second
	}

	update_BARs(pattern_LED1,pattern_LED2); //exit key pressed, reset LED's to clear
	return;
}	


void custom_define(char side)  //defining a new custom spray pattern
{
	char form[56];
	char temp[32];
	char location=0;
	short hexVal[2] = {0,0};
	char pattern=0;
	char duration;
	char i;
	char F5=0;
	char scan=0;

	LCD_Clear();
	sprintf(temp, "Define Custom Spray\r52 Cycles Max\rF5 Exits\rF1 = F"); //instructions
	LCD_PutString(temp);
	msleep(1000); //desplay instructions for about 1 second
	LCD_Clear();
	LCD_ClearBuffer();
	
	while(!F5 && location < 52)// && pattern != QTERM_F5_KEY) //while user isn't done, or array full
	{
		scan = ReadSerialPort(SERPORT_LCD); //check for a pressed F5 key
		if( scan == QTERM_F5_KEY ) F5 = 1;
	
		sprintf(temp, "Enter Hex Pattern:\r0x");
		LCD_PutString(temp);
		hexVal[0]=0;
		hexVal[1]=0;
		
		while( ( !(hexVal[0] >= '0' && hexVal[0] <= '9') && !(hexVal[0] >= 'A' && hexVal[0] <= 'F') ) && hexVal[0]!=QTERM_F5_KEY) 	
		{											//continue scanning till a valid selection or F5
			while(SerialReady(SERPORT_LCD)) { }	
			hexVal[0] = ReadSerialPort(SERPORT_LCD);
			if(hexVal[0]>='F' && hexVal[0]<='J') hexVal[0]-=5; //get A-E reguardless of status of shift
			if(hexVal[0]==QTERM_F1_KEY)		hexVal[0] = 70;    //get F if F1 is pressed
			msleep(25);	//don't know why I need this, but found to keep out the 0x01.
		}	
		if( hexVal[0] != QTERM_F5_KEY) //aslong as exit isn't selected go on
		{
			LCD_PutChar(hexVal[0]);	//echo pressed charicter
			LCD_ClearBuffer();
			
			while( ( !(hexVal[1] >= '0' && hexVal[1] <= '9') && !(hexVal[1] >= 'A' && hexVal[1] <= 'F') ) && hexVal[1]!=QTERM_F5_KEY) 	
			{										//continue scanning till a valid selection or F5
				while(SerialReady(SERPORT_LCD)) { }	
				hexVal[1] = ReadSerialPort(SERPORT_LCD);
				if(hexVal[1]>='F' && hexVal[1]<='J') hexVal[1]-=5;//get A-E reguardless of status of shift
				if(hexVal[1]==QTERM_F1_KEY)		hexVal[1] = 'F';//get F if F1 is pressed
				msleep(25);	//don't know why I need this, but found to keep out the 0x01.


			}	
		
			if( hexVal[1] != QTERM_F5_KEY)
			{	
				LCD_PutChar(hexVal[1]);
		
				LCD_ClearBuffer(); pattern=-1;
		
				if(hexVal[0]>'9') hexVal[0]-=7; //convert A->10, F->15 ect
				if(hexVal[1]>'9') hexVal[1]-=7;
				pattern=hexVal[0]-48;			//convert '0'->0, '9'->9 ect
				pattern*=16;					//convert decimal to hex
				pattern+=hexVal[1]-48;			
			
				sprintf(temp, "\rEnter Duration\r(1-4 Cycles): "); //length of cycle
				LCD_PutString(temp);
				
				LCD_ClearBuffer(); duration=-1;
			
				while( ( duration < '1' || duration > '4' ) && duration != QTERM_F5_KEY ) 
				{				//keep scanning untill valid input or exit key
					while(SerialReady(SERPORT_LCD)) { }	
					duration = ReadSerialPort(SERPORT_LCD);
				}
				
				LCD_Clear();		
				if(duration != QTERM_F5_KEY)  //if exit is selected durring duration selection, throw out the hex value
				{	duration-=48;
					
					for( i=0; i<duration; i++)
					{
						form[location]=pattern;
						location++;
					}	
				}
				else F5=1;	//exit was selected, update the loop
			}
			else F5=1;//exit was selected, update the loop
		}
		else F5=1; //exit was selected, update the loop
	}
	if (location>52) location = 52;  //only copy first 52 cycles
	
	if(side=='l') // called for left custom
	{
		l_custom_length=location;  //copy length
		for(i=0; i<=location; i++)	//copy array one element at a time
			left_custom_pattern[i]=form[i];
	}
	
	else  // called for right custom
	{
		r_custom_length=location;  //copy length
		for(i=0; i<=location; i++)  //copy array one element at a time
			right_custom_pattern[i]=form[i];
	}

	return;
}	



void update_BARs(char pattern_LED1,char pattern_LED2)  //simple print to LED function
{
	char * pBAR1 = (char *) IO_DIGITAL_OUTPUT_LED1;
	char * pBAR2 = (char *) IO_DIGITAL_OUTPUT_LED2;
	
	//*pBAR1=~*pBAR1
	
	*pBAR1=~pattern_LED1;  //print the inverted pattern so the lit pattern is pattern_LED
	*pBAR2=~pattern_LED2; 

	return;
}
