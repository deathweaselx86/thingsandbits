// PPC_Support.c : Support function for PowerPC board
///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2001	Iowa State University 
// All rights reserved.
//
// Department of Electrical & Computer Engineering
// Iowa State University
// Ames, IA 50010
//
// http://www.ee.iastate.edu/
//
///////////////////////////////////////////////////////////////////////////////
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
// 3. All advertising materials mentioning features or use of this software
//    must display the following acknowledgement:
// 		This product includes software developed by the Iowa State 
//      University.
// 4. Neither the name of the University nor of the Research Group may be used
//    to endorse or promote products derived from this software without
//    specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////////

#include "Defines.h"

#define TICKS_PER_MS		1249		// 1249 ticks per milli-second (Approx.)

void	msleep_1ms ()
{
	short	*		pPISCR	= (short *) 0x002FC240;
	long	*		pPITC 	= (long *)  0x002FC244;	
	long	*		pPITR	= (long *)  0x002FC248;	

	// Clear the PS to zero
	//	Writing a 1 clears the flag
	
	*pPISCR = *pPISCR;		// If it is a 1, it will get
							//  cleared by virtue of writing back
							//  out the result
							
	// Activate the PIT timer

	*pPISCR = 0x0080;

	// Set PITC to the value per millisecond to count down
	
	*pPITC = (TICKS_PER_MS) << 16;

	*pPISCR = 0x0001;
	
	while(!(*pPISCR & 0x0080))
	{
	}
		
	*pPISCR = 0x0880;
}

///////////////////////////////////////////////////////////////////////////////
// void	msleep (int nMilliSeconds)
//
// Sleep for X number of milliseconds using the PIT

void	msleep (int nMilliSeconds)
{
	int		j;
	
	for(j=0; j<nMilliSeconds; j++)
	{
		msleep_1ms();
	}
}