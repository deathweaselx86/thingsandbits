//sprayer.c : Main C source file for Cpr E 211 lab 5
//////////////////////////////////////////////////////////////
// Authors:		Alex McLaren			mcalex9@iastate.edu
//				Jessica Ross			rossjr@iastate.edu
//
// Lab:			12-2 PM, Thursday
//	
// TA:		Qiang Qiu	
//
// Instructor:	Tyagi
//
//////////////////////////////////////////////////////////////
// Description:
//
//  source code for the sprayer functions for lab 5 sprayers
//////////////////////////////////////////////////////////////

// Include Files
#include "defines.h"
#include "sprayer.h"

void light_none(char* arm)
{
	*arm = 0xFF; //all bits off
}

void light_even(char* arm)
{
	*arm = 0xAA; //all odd bits off
}

void light_odd(char* arm)
{
	*arm = 0x55; //all even bits off
}

void light_all(char* arm)
{
	*arm = 0x00; //all of them on
}



void all1(char* arm)
{

	/*
	
	
	 Turn on all nozzles for the right arm, both inner and outer, in a timed pattern.
	 In the array of LEDs, light all even LEDs (bits 0, 2, 4, 6) at once, for 0.5 sec. 
	 Then light all odd LEDs (bits 1, 3, 5, 7) at once, for 0.5 sec. Then light all LEDs 
	 for 0.5 sec. Finally, turn off all LEDs, and wait 1 sec before repeating the process again.

	 Let * indicate LED on, and - LED off.

	 Sequence of LED patterns:
	  -*-*-*-* � *-*-*-*-  � ********  � --------  � -*-*-*-* 
	etc., where each pattern holds for 0.5 sec with a second between repeats. */
	
	static int state=0; //This allows us to save state
	
	switch(state)
	{
		case 0:	light_even(arm); //lights even bits of the LED
				break;
		case 1:	break; 	//This is a timing break; there are a lot of these so we can control 
						//timing
		case 2:	light_odd(arm); //lights odd bits of the LED
				break;
		case 3:	break;
		case 4:	light_all(arm); //lights all of the bits of the LED
				break;
		case 5: break;
		case 6:	light_none(arm); //turns all bits off
				break;//Timing break for 
		case 7: break;//one
		case 8: break;//agonizing
		case 9:	break;//second
	}
	
	state++;
	if(state > 10)
		state =0;
}

void all2(char* arm)
{

	
	/*
	
	
	 Turn on all nozzles for the left arm, both inner and outer, in a timed pattern.
	 In the array of LEDs, light all even LEDs (bits 0, 2, 4, 6) at once, for 0.5 sec. 
	 Then light all odd LEDs (bits 1, 3, 5, 7) at once, for 0.5 sec. Then light all LEDs 
	 for 0.5 sec. Finally, turn off all LEDs, and wait 1 sec before repeating the process again.

	 Let * indicate LED on, and - LED off.

	 Sequence of LED patterns:
	  -*-*-*-* � *-*-*-*-  � ********  � --------  � -*-*-*-* 
	etc., where each pattern holds for 0.5 sec with a second between repeats. */
	
	static int state=0;
	
	switch(state)
	{
		case 0:	light_even(arm); //lights all even bits of LED
		case 1:	break;//This is a timing break; there are a lot of these so we can control 
						//timing
		case 2:	light_odd(arm); //lights all odd LED bits
				break;
		case 3:	break;
		case 4:	light_all(arm); //lights all LED bits
				break;
		case 5: break;
		case 6:	light_none(arm); //lights none of the LED bits
				break;//Long agonizing break for 1 second
		case 7: break;
		case 8: break;
		case 9:	break;
	}
	
	state++;
	if(state > 10)
		state =0;
}

void outer1(char* arm)
{

	/*
	
			Turn on outer boom nozzles only in a timed pattern for the right arm.

			Light the right-half LEDs, adding one at a time, from left to right,
			starting at bit 3 and moving outward to bit 0. Each pattern should
			hold for 0.5 sec.

			Sequence of LED patterns:
			--------  � ----*---  � ----**--  � ----***-  � ----****  � -------- 
			etc.
		*/
	static int state=0;
	switch(state)
	{
		case 0:		*arm = 0xFF; //all bits off
					break;
		case 1:		break;
		case 2:		*arm = 0xF7; //all bits except for 3rd off
					break;
		case 3:		break;
		case 4:		*arm = 0xF3; //all bits except for 2nd & 3rd off
				    break;
		case 5:		break;
		case 6:		*arm = 0xF1; //all bits off except for 2nd,3rd,and 1st off
				  	break;
		case 7:		break;
		case 8:		*arm = 0xF0; //all off except lower 4 bits
					break;
		case 9:		break;
	}
	
	state++;
	if(state > 9)
		state = 0;
}

void outer2(char* arm)
{

	/*
	
			Turn on outer boom nozzles only in a timed pattern for the left arm.

			Light the right-half LEDs, adding one at a time, from left to right,
			starting at bit 3 and moving outward to bit 0. Each pattern should
			hold for 0.5 sec.

			Sequence of LED patterns:
			--------  � ----*---  � ----**--  � ----***-  � ----****  � -------- 
			etc.
		*/
	static int state=0;
	switch(state)
	{
		case 0:		*arm = 0xFF;   //all bits off
					break;
		case 1:		break;
		case 2:		*arm = 0xF7;    //all bits except for 3rd off
					break;
		case 3:		break;
		case 4:		*arm = 0xF3;  //all bits except for 2nd & 3rd off
				    break;
		case 5:		break;
		case 6:		*arm = 0xF1;   //all bits off except for 2nd,3rd,and 1st off
				  	break;
		case 7:		break;
		case 8:		*arm = 0xF0;  //all off except lower 4 bits
					break;
		case 9:		break;
	
	}
	
	state++;
	if(state > 9)
		state=0;
}


void inner1(char* arm)
{
	/*
	
	Turn on inner boom nozzles only in a timed pattern for the right arm.

	Light the left-half LEDs, adding one at a time, from right
	to left, starting at bit 4 and moving outward to bit 7. Each
	pattern should hold for 0.5 sec.

	Sequence of LED patterns:
	--------  � ---*----  � --**----  � -***----  � ****----  � --------  
	etc.
	*/
		
	static int state=0;
	switch(state)
	{
		case 0:		*arm = 0xFF; //all bits off
					break;
		case 1:		break;
		case 2:		*arm = 0xEF;  //all bits off except the most significant
					break;
		case 3:		break;
		case 4:		*arm = 0xCF; //all bits off except 7th and 6ths bits
				    break;
		case 5:		break;
		case 6:		*arm = 0x8F; //all bits off except 7th,6th,and 5th
				  	break;
		case 7:		break;
		case 8:		*arm = 0x0F; //all bits off except 7th,6th, 5th, 4th
					break;
		case 9:		break;
		
	}
	
	state++;
	if(state > 9)
		state = 0;
}


void inner2(char* arm)
{

	/*
	Turn on inner boom nozzles only in a timed pattern for the left arm.

	Light the left-half LEDs, adding one at a time, from right
	to left, starting at bit 4 and moving outward to bit 7. Each
	pattern should hold for 0.5 sec.

	Sequence of LED patterns:
	--------  � ---*----  � --**----  � -***----  � ****----  � --------  
	etc.
	*/
	static int state=0;
	switch(state)
	{
		case 0:		*arm = 0xFF; //all bits off
					break;
		case 1:		break;
		case 2:		*arm = 0xEF; //all bits off except the most significant
					break;
		case 3:		break;
		case 4:		*arm = 0xCF; //all bits off except 7th and 6ths bits
				    break;
		case 5:		break;
		case 6:		*arm = 0x8F; //all bits off except 7th,6th,and 5th
				  	break;
		case 7:		break;
		case 8:		*arm = 0x0F; //all bits off except 7th,6th, 5th, 4th
					break;
		case 9:		break;
		
	}
	
	state++;
	if(state > 9)
		state = 0;
}

void test1(char* arm)
{
	static int state=0;
	/*
		Turn on each nozzle for a particular arm, one after another, in a pendulum pattern.
		Light one LED at a time, and shift the lit LED to the left and right, back and forth, at
 		1/4-sec intervals. The light moves left first, then bounces back to the right, and so on.

		Sequence of LED patterns:
		-------* � ------*-  � -----*--  � ----*---  � ---*----  � --*----- 
		� -*------  � *------- � -*------ etc., where each pattern is held for 250 msec.
		*/
	switch(state)
	{
		/* This is sort of self explanatory. Each one of these statements lights just one bit of 
		the LED at a time, starting with the extreme right, then to the extreme left, and back
		again. Only one light is lit for each run through this switch. This is controlled by main. */
		case 0: *arm = 0xFE; 
				break;
				
		case 1: *arm = 0xFD;
				break;
				
		case 2:	*arm = 0xFB;
				break;
				
		case 3:	*arm = 0xF7;
				break;
				
		case 4:	*arm = 0xEF;
				break;
				
		case 5: *arm = 0xDF;
				break;
				
		case 6: *arm = 0xBF;
				break;
				
		case 7: *arm = 0x7F;
				break;
				
		case 8: *arm = 0xBF;
				break;
				
		case 9: *arm = 0xDF;
				break;
				
		case 10:*arm = 0xEF;
				break;
				
		case 11:*arm = 0xF7;
				break;
				
		case 12:*arm = 0xFB;
				break;
				
		case 13:*arm = 0xFD;
				break;
	}
	
	state++;
	if(state > 13)
		state = 0;
}


void test2(char* arm)
{
	static int state=0;
	/*
		Turn on each nozzle for a particular arm, one after another, in a pendulum pattern.
		Light one LED at a time, and shift the lit LED to the left and right, back and forth, at
 		1/4-sec intervals. The light moves left first, then bounces back to the right, and so on.

		Sequence of LED patterns:
		-------* � ------*-  � -----*--  � ----*---  � ---*----  � --*----- 
		� -*------  � *------- � -*------ etc., where each pattern is held for 250 msec.
		*/
	
	switch(state)
	{
	
		/* This is sort of self explanatory. Each one of these statements lights just one bit of 
		the LED at a time, starting with the extreme right, then to the extreme left, and back
		again. Only one light is lit at a time. */
		case 0: *arm = 0xFE;
				break;
				
		case 1: *arm = 0xFD;
				break;
				
		case 2:	*arm = 0xFB;
				break;
				
		case 3:	*arm = 0xF7;
				break;
				
		case 4:	*arm = 0xEF;
				break;
				
		case 5: *arm = 0xDF;
				break;
				
		case 6: *arm = 0xBF;
				break;
				
		case 7: *arm = 0x7F;
				break;
				
		case 8: *arm = 0xBF;
				break;
				
		case 9: *arm = 0xDF;
				break;
				
		case 10:*arm = 0xEF;
				break;
				
		case 11:*arm = 0xF7;
				break;
				
		case 12:*arm = 0xFB;
				break;
				
		case 13:*arm = 0xFD;
				break;
	}
	
	state++;
	if(state > 13)
		state = 0;
}