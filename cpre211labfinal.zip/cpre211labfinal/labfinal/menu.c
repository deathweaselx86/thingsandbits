
#include "QTerm.h"			// Accessing the QTerm-J10 Terminal
#include "serial.h"			// Accessing the serial ports
#include "PPC_Support.h"	
#include "defines.h"


int menu(char * passwd)
{
	char myOption='0', myBacklight='0', myContrast='0';
	LCD_Init();
	//display menu
	//person enters a character from the 
	
	
	
		LCD_PutString("1 - LOCK\r");
		LCD_PutString("2 - CHANGE PW\r");
		LCD_PutString("3 - RUN SPRAYER\r");
		LCD_PutString("4 - COMMUNICATOR\r");
		while(1)
		{
			if(!SerialReady(2))
				myOption = ReadSerialPort(2);
			switch(myOption)
			{
				case '1':		//relock
								return 1;
								break;
				case '2':		//change password
								//module here
				case '3':		//run sprayer
		
								break;
				case '4':		//communication system
								break;
				case '5':		//LCD Backlight toggle
								Set_LCD_Backlight(myBacklight%3);
								break;
				case '6':		//LCD Contrast 
								Set_LCD_Contrast(myContrast%100);	
								break;
			
		}
	}
	return 0;

}
