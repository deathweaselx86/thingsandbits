/* ===========================================================================
	serial.c
	--------
	Serial port I/O and ASCII String Formatting Functions

 (C) Copyright 1999 Axiom Manufacturing.  All rights reserved.
============================================================================*/

#include "diab.h"
#include "serial.h"

UNS8 SByte;		// just received data byte
UNS8 inbuf[INBUFSIZE];
UNS8 inbyte;
UNS16 Rcount, Wcount;
UNS32 Addr, StartAddr, EndAddr;
UNS16 ioport = 1;	// 0 = use SC0 for standard i/o.  1 = use SC1
UNS8 echo;

/*----------------------------------------------------------------------------
----------------------------------------------------------------------------*/
void InitCom(char portnum){
	if(portnum == 0){
//		Com1Con0 = 130;		// 9600 baud with 40mh internal clock	(pll reg - 0x09)  (0-11 value)
		Com1Con0 = 65;		// 9600 baud with 20mh internal clock 	(pll reg - 0x04)  (0-11 value)
//		Com1Con0 = 13;		// 9600 baud with 4mh internal clock
		Com1Con1 = 0x000C;	// Transmit & Receive Enabled, no parity, no interrupts
	}
	else{
		Com2Con0 = 65;		// 9600 baud with 20mh internal clock 	(pll reg - 0x04)  (0-11 value)
		Com2Con1 = 0x000C;	// Transmit & Receive Enabled, no parity, no interrupts
	}
}

// reset / clear the watchdog
void ClearWatchdog(){
	WatchDog = 0x556C;	// clear the watchdog
	WatchDog = 0xAA39;
}

/*----------------------------------------------------------------------------
ReadyToSend
-----------
 Wait for the serial port Status register to indicate the transmiter is
 ready to receive another byte.

 INPUT:		ioport		0= SCI1, 1= SCI2
 OUTPUT:    returns 0 when ready.  NO TIMEOUT is currently implemented
----------------------------------------------------------------------------*/
char ReadyToSend(char portnum){
	short Status;
	do{	// wait for transmit byte sent to the shift register, ready for another
		if(portnum == 0)	Status = Com1Status;
		else                Status = Com2Status;
		ClearWatchdog();	// feed the dog
	}while((Status & 0x0100) == 0);
	return 0;
}


/*----------------------------------------------------------------------------
putchar
-------
 Wait for the serial port transmiter to return ready then write a single byte
 to the transmit register.

 INPUT:		sbyte		Value to write
			ioport		0= SCI1, 1= SCI2
 OUTPUT:    returns 0 when finished.  NO TIMEOUT is currently implemented
----------------------------------------------------------------------------*/
unsigned char putchar(unsigned char sbyte){
	if(ReadyToSend(ioport))	return 1;	// wait for ready to send
	if(ioport == 0)	Com1Data = (short) sbyte;
	else            Com2Data = (short) sbyte;
	return 0;
}

/*----------------------------------------------------------------------------
putch
-----
 Send a single byte out the serial port.
 If this is the '\n' character then 2 bytes are sent which are the carriage
 return followed by line feed characters.

 INPUT:		ch			Value to write
 			ioport		0= SCI1, 1= SCI2
----------------------------------------------------------------------------*/
void putch(UNS8 ch){

	if (ch == '\n'){
		putchar(CR);
		putchar(LF);
	}
	else{
		putchar(ch);
	}
}

/*----------------------------------------------------------------------------
puts
----
 Send a string of characters to the serial port.  The string must end in a
 NULL character (0x00).

 INPUT:		sptr		pointer to the string
 			ioport		0= SCI1, 1= SCI2
----------------------------------------------------------------------------*/
void puts(char *sptr){
	while(*sptr){
		putch(*sptr);
		++sptr;
	}
}

/*----------------------------------------------------------------------------
SerialReady
-----------
 returns 0 if any new serial data has been received

 INPUT:		portnum		0= SCI1, 1= SCI2
 OUTPUT:    returns 0 when new data is ready, 1 otherwise.
----------------------------------------------------------------------------*/
unsigned char SerialReady(unsigned char portnum){
	short Status;

	ClearWatchdog();	// feed the dog
	if(portnum == 0)	Status = Com1Status;
	else                Status = Com2Status;

	if( (Status & 0x0040) == 0)		return 1;	// no data ready
	return 0;	// data ready
}

/*----------------------------------------------------------------------------
ReadSerialPort
--------------
 Reads a single byte from the selected serial port

 INPUT:		pnum		0= SCI1, 1= SCI2
 OUTPUT:
			SByte		contains the read byte on return
 			returns the byte that was received
----------------------------------------------------------------------------*/
char ReadSerialPort(char pnum){
	short Temp1;

	if(pnum == 0)	Temp1 = Com1Data; 	// read the port
	else            Temp1 = Com2Data; 	// read the port
	SByte = (unsigned char) (Temp1 & 0x00FF);
	return SByte;
}

/*----------------------------------------------------------------------------
GetSByte
--------
 Wait for a single byte to be received from the serial port then read it.

 INPUT:		ioport		0= SCI1, 1= SCI2
 OUTPUT:
			SByte		contains the read byte on return
 			returns the byte that was received
----------------------------------------------------------------------------*/
UNS8 GetSByte(){
	while(SerialReady(ioport) == 1) ;	// wait for new incomming data
	return(ReadSerialPort(ioport));
}
/*----------------------------------------------------------------------------
kbhit
-----
 returns 0 if any new serial data has been received
 (does the same thing as SerialReady() but uses the global ioport variable)

 INPUT:		ioport		0= SCI1, 1= SCI2
 OUTPUT:    returns 0 when new data is ready, 1 otherwise.
----------------------------------------------------------------------------*/
UNS8 kbhit(){
	return(SerialReady(ioport));
}

/*----------------------------------------------------------------------------
GetString
---------
 Receive a string from the serial port.  The string is ended when either the
 CR or LF characters are received (sent when ENTER is pressed on the terminal).

 This function leaves the string in the inbuf[ ] array with:
		Rcount the index offset of the beginning of the string and
		Wcount pointing to the end of the string (0).

 INPUT:		ioport		0= SCI1, 1= SCI2
 OUTPUT:
 			inbuf[]		Global string buffer - contains the input string
 			Rcount		Index string start position in inbuf[]
 			Wcount		Index string end position in inbuf[]
 			returns 0 when finished.  NO TIMEOUT is currently implemented
----------------------------------------------------------------------------*/
UNS8 GetString(){
	UNS16	Wsave;

	Rcount = 0;
	Wcount = 0;
	Wsave = Wcount;

	GetSByte();	// wait for data to be received
	while(SByte != 0x0D && SByte != 0x0A){
		if(echo == TRUE){
			if(SByte == 0x7F || SByte == 0x18){	// if DEL or CTLX pressed
				Wcount = Wsave;
			}
			else if(SByte == 0x08){	// if Backspace
				putchar(SByte);	// echo input byte
				if(Wcount > Wsave) --Wcount;
			}
			else{
				putch(SByte);	// echo input byte
				inbuf[Wcount] = tolower(SByte);	// save the byte in the input buffer
				++Wcount;
			}
		}
		else{
			inbuf[Wcount] = tolower(SByte);	// save the byte in the input buffer
			++Wcount;
		}
		if(Wcount > INBUFSIZE)	--Wcount;	// don't receive more than we can store
		GetSByte();	// wait for more data to be received
	}
	inbuf[Wcount] = 0;	// null terminate the string

	return 0;
}

/*----------------------------------------------------------------------------
tohex
-----
 Takes an ASCII hex character (a-f, 0-9) as input and returns the integer it
 represents.

 INPUT:		number		ASCII value to convert
 OUTPUT:	returns 16-bit binary value
----------------------------------------------------------------------------*/
unsigned tohex(UNS16 number){
	if(number > 47 && number < 58)		// if 0-9
		return(number-48);
	else if(number > 64 && number < 71) // A-F
		return((number-65) + 10);
	else	return((number-97) + 10);	// a-f
}

/*----------------------------------------------------------------------------
LowNibble
HighNibble
---------
 Returns the High or Low nibble of a Byte

 INPUT:		byte		value
 OUTPUT:	returns 4-bit value
----------------------------------------------------------------------------*/
UNS16 LowNibble(UNS16 byte){
	byte &= 0x0F;
	return(byte);
}
UNS16 HighNibble(UNS16 byte){
	byte >>= 4;
	return(byte);
}
/*----------------------------------------------------------------------------
HiByte
LoByte
------
 Returns the High or Low byte of a Word

 INPUT:		word		value
 OUTPUT:	returns 8-bit value
----------------------------------------------------------------------------*/
UNS16 HiByte(UNS16 word){
	word >>= 8;
	return(word);
}
UNS16 LoByte(UNS16 word){
	word &= 0x00FF;
	return(word);
}

/*----------------------------------------------------------------------------
strlength
---------
 Returns the number of bytes in a 0 terminated string.
 The 0 is not counted.

 INPUT:		sptr		pointer to the string
 OUTPUT:	returns the length of the string
----------------------------------------------------------------------------*/
UNS16 strlength(char *sptr){
	UNS16 strlencount;
	strlencount=0;
	while(*sptr != 0){
		++strlencount;
		++sptr;
	}
	return(strlencount);
}

/*----------------------------------------------------------------------------
StrHexNum
---------
 Converts a string of ASCII HEX characters to an integer

 INPUT:		sptr		pointer to the string
			bytes		number of bytes in the string to convert
 OUTPUT:	returns the binary number that the hex string represents
----------------------------------------------------------------------------*/
unsigned StrHexNum(char *ptr, UNS8 bytes){
	unsigned	cval;
	unsigned	hold;

	UNS16 numbs;

	numbs = strlength(ptr);  // get number of digits in the string

	if(bytes == 2){
		if(numbs > 3){	// if 4 numbers in string
			hold = tohex(*ptr);
			hold <<= 12;
			cval = tohex(*(ptr+1));
			cval <<= 8;
			hold += cval;
			cval = tohex(*(ptr+2));
			cval <<= 4;
			hold += cval;
			hold += tohex(*(ptr+3));
		}
		else if(numbs > 2){	// if 3 numbers in string
			hold = tohex(*ptr);
			hold <<= 8;
			cval = tohex(*(ptr+1));
			cval <<= 4;
			hold += cval;
			hold += tohex(*(ptr+2));
		}
		else if(numbs > 1){	// if 2 numbers in string
			hold = tohex(*ptr);
			hold <<= 4;
			hold += tohex(*(ptr+1));
		}
		else {
			hold = tohex(*ptr);
		}
	}
	else{
		if(numbs > 1){
			hold = tohex(*ptr);
			hold <<= 4;
			hold += tohex(*(ptr+1));
		}
		else{
			hold = tohex(*ptr);
		}
	}
	return(hold);
}

/*----------------------------------------------------------------------------
StrAddr
---------
 Converts a string of ASCII HEX characters to a 4 byte address

 INPUT:     ptr        pointer to the string
 OUTPUT:	returns the binary number that the hex string represents
----------------------------------------------------------------------------*/
unsigned long StrAddr(unsigned char *ptr){
    unsigned long holdaddr;

    holdaddr = StrHexNum((char *) ptr, 2);
    holdaddr *= 0x10000;
    holdaddr += StrHexNum((char *) (ptr+4), 2);

    return(holdaddr);
}


/*----------------------------------------------------------------------------
hexvalue
--------
 Test a number to see if it is a valid HEX digit (0-F)

 INPUT:		number		character to test
 OUTPUT:	returns 1 if this is a HEX character, 0 otherwise
----------------------------------------------------------------------------*/
char hexvalue(char number){
	if(number > 47 && number < 58)		// if 0-9
		return 1;
	if(number > 96 && number < 123)		// a-f
		return 1;
	if(number > 64 && number < 71) 		// A-F
		return 1;
	return 0;
}

/*----------------------------------------------------------------------------
reverse
-------
 Reverse the character order of a 0 terminating string

 INPUT:		rptr		pointer to the string
 OUTPUT:	rptr		new string
----------------------------------------------------------------------------*/
void reverse(char *rptr){
	UNS16 countb, counte, middle;
	char tbyte;

	counte = (strlength(rptr)) - 1;  // get number of digits in the string
	for(countb=0; countb < counte; countb++, counte--){
		tbyte = *(rptr+countb);
		*(rptr+countb) = *(rptr+counte);
		*(rptr+counte) = tbyte;
	}
}

/*----------------------------------------------------------------------------
itoa
----
 Convert a number to a 0 terminating ASCII string representing a Base 10
 Decimal Value

 INPUT:		n		number to convert
 			s		pointer to the array to hold the string
----------------------------------------------------------------------------*/
void itoa(unsigned long n, char *s){
  unsigned long sign;
  char *ptr;

  ptr = s;
  if ((sign = n) < 0) n = -n;
  do {
    *ptr++ = n % 10 + '0';
    } while ((n = n / 10) > 0);
  if (sign < 0) *ptr++ = '-';
  *ptr = '\0';
  reverse(s);
}

/*----------------------------------------------------------------------------
htoa
----
 Convert a number to a 0 terminating ASCII string representing a Base 16 HEX
 Value

 INPUT:		n		number to convert
 			s		pointer to the array to hold the string
----------------------------------------------------------------------------*/
void htoa(unsigned long n, char *s){
  char *ptr;
  char val;

  ptr = s;
  do{
	val = n % 16;
	if(val < 10) val += '0';
	else val += 55;
	*ptr++ = val;
  } while ((n = n / 16) > 0);
  *ptr = '\0';
  reverse(s);
}

/*----------------------------------------------------------------------------
puth
----
 Output an ASCII HEX string representation of a number to the serial port

 INPUT:		num		number to send
 			width	number of digits to output.  if > than the size of the
					number, it is padded with 0's
----------------------------------------------------------------------------*/
void puth(unsigned long num, int width){
	char tempbuf[11];
	int counte;

	htoa(num, tempbuf);
	counte = (strlength(tempbuf));  // get number of digits in the string
	while(counte < width){	// padd with 0
		putch(0x30);
		--width;
	}
	puts(tempbuf);
}
/*----------------------------------------------------------------------------
puti
----
 Output an ASCII Decimal string representation of a number to the serial port

 INPUT:		num		number to send
----------------------------------------------------------------------------*/
void puti(unsigned long num){
	char tempbuf[7];

	itoa(num, tempbuf);
	puts(tempbuf);
}

/*----------------------------------------------------------------------------
getn
----
 Receive a specific number of bytes from the serial port.

 INPUT:		num			number of bytes to receive
			ioport		0= SCI1, 1= SCI2
 OUTPUT:	inbuf[]	    global array buffer containing the bytes that were
						received.  A 0x00 will be added to the end.
 			Wcount		Index string end position in inbuf[]
----------------------------------------------------------------------------*/
void getn(char num)
{
	Wcount = 0;
	while(Wcount < num){
		GetSByte();
		inbuf[Wcount] = SByte;
		++Wcount;
	}
	inbuf[Wcount] = 0;
	
	return;
}

/*----------------------------------------------------------------------------
GetAddr
-------
 Convert a long address from the input string starting at Rcount

 INPUT:		inbuf[]		Global string buffer - contains the address string
 OUTPUT:
			returns 1 if not a valid hex number, 0 otherwise
			returns with Rcount pointing to the byte following the number
----------------------------------------------------------------------------*/
char GetAddr(){
	char count;

	// the first digit must be valid
	if(hexvalue(inbuf[Rcount]) == 0)	return 1;
	Addr = tohex(inbuf[Rcount]);
	++Rcount;

	// convert the rest until a non-valid one found
	for(count=1; count < 8; count++){
		if(hexvalue(inbuf[Rcount]) == 0)	return 0;
		Addr *= 0x10;
		Addr += tohex(inbuf[Rcount]);
		++Rcount;
	}
	return 0;
}
